# gui.py
import tkinter as tk
import customtkinter as ctk
from assistant_core import listen, speak, get_wikipedia_answer
from media_control import open_app, play_youtube_video
from smart_features import shutdown_computer
from smart_features import *

def handle_command():
    cmd = listen().lower()
    
    if "open" in cmd:
        # Handle app openings
        if "youtube" in cmd:
            open_app("youtube")
        elif "instagram" in cmd:
            open_app("instagram")
        elif "whatsapp" in cmd:
            open_app("whatsapp")
        elif "website" in cmd:
            website = cmd.split("website")[-1].strip()
            open_website(website)
        else:
            app = cmd.replace("open", "").strip()
            open_app(app)
            
    elif "play" in cmd:
        video = cmd.replace("play", "").strip()
        play_youtube_video(video)
    elif "weather" in cmd:
        city = cmd.split("in")[-1].strip()
        get_weather(city)
    elif "news" in cmd:
        get_news()
    elif "email" in cmd:
        send_email("receiver@example.com", "Hello", "This is from Jarvis!")
    elif "whatsapp" in cmd:
        send_whatsapp("+919893042776", "Hi from Jarvis!")
    elif "note" in cmd:
        save_note(cmd.replace("note", "").strip())
    elif "joke" in cmd:
        tell_joke()
    elif "search" in cmd or "wikipedia" in cmd:
        topic = cmd.replace("search", "").replace("wikipedia", "").strip()
        answer = get_wikipedia_answer(topic)
        speak(answer)
    elif "launch" in cmd or "start" in cmd:
        app_name = cmd.replace("launch", "").replace("start", "").strip()
        open_desktop_app(app_name)
    elif "save note" in cmd and "notepad" in cmd:
        automate_option_inside_app("notepad")
    elif "shutdown" in cmd or "turn off computer" in cmd:
        shutdown_computer()


    else:
        speak("Sorry, I can't do that yet.")



# GUI creation
def create_gui():
    ctk.set_appearance_mode("light")  # "dark", "light", or "system"
    ctk.set_default_color_theme("blue")  # Themes: blue, green, dark-blue

    window = ctk.CTk()
    window.title("JARVIS Panel")
    window.geometry("450x300")
    window.resizable(False, False)

    # Title
    title_label = ctk.CTkLabel(
        window,
        text="🎙️ JARVIS Voice Assistant",
        font=ctk.CTkFont(size=22, weight="bold"),
        text_color="#1E90FF"
    )
    title_label.pack(pady=30)

    # Activate Button
    activate_button = ctk.CTkButton(
        window,
        text="🎧 Activate",
        command=handle_command,
        font=ctk.CTkFont(size=14),
        width=200,
        height=45,
        corner_radius=12
    )
    activate_button.pack(pady=10)

    # Status Label
    status_label = ctk.CTkLabel(
        window,
        text="Status: Waiting...",
        font=ctk.CTkFont(size=12),
        text_color="gray"
    )
    status_label.pack(pady=10)

    window.mainloop()

if __name__ == '__main__':
    create_gui()
