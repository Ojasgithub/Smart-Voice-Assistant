# assistant_core.py
import pyttsx3
import wikipedia
import speech_recognition as sr
import openai
from config import OPENAI_API_KEY

engine = pyttsx3.init()
openai.api_key = OPENAI_API_KEY

def speak(text):
    engine.say(text)
    engine.runAndWait()

def listen():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("🎤 Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)
    try:
        print("🔍 Recognizing...")
        return r.recognize_google(audio)
    except:
        speak("Sorry, I didn't get that.")
        return ""

def get_wikipedia_answer(query):
    try:
        summary = wikipedia.summary(query, sentences=1)  # Get a brief summary (1 sentence)
        return summary
    except wikipedia.exceptions.DisambiguationError as e:
        return f"Your query is too ambiguous. Here are some options: {e.options}"
    except wikipedia.exceptions.HTTPTimeoutError:
        return "Sorry, I couldn't fetch information right now due to a timeout."
    except Exception as e:
        return f"Sorry, there was an error: {e}"

