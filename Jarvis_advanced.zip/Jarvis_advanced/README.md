# 🤖 JARVIS Voice Assistant (Final Year Major Project)

This is a Python-based Voice Assistant project inspired by Iron Man’s JARVIS.  
Built with ❤️ by a team of 3 Computer Science students.

---

## 👨‍💻 Team Members

- **Member 1**: Voice Commands, ChatGPT Integration (`assistant_core.py`)
- **Member 2**: GUI + App Control + YouTube (`media_control.py`, `gui.py`)
- **Member 3**: Smart Features (Weather, News, WhatsApp, Email, Notes, Jokes) (`smart_features.py`)

---

## 🔥 Features

✅ Open Applications  
✅ Open Websites
✅ Chat with Wikipedia 
✅ YouTube Music/Video Playback  
✅ Send WhatsApp Messages  
✅ Send Emails  
✅ Get Weather Updates  
✅ Get News Headlines  
✅ Save Voice Notes  
✅ Crack Jokes  
✅ Simple GUI Interface  

---

## 📁 File Structure

