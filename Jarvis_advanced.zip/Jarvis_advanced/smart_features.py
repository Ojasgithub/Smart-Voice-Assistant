# smart_features.py
import webbrowser
import os
import subprocess
import time
import pyautogui
import requests
import smtplib
import pyjokes
import pywhatkit
import feedparser
from assistant_core import speak
from config import WEATHER_API_KEY, NEWS_API_KEY, EMAIL, PASSWORD


def open_desktop_app(app_name):
    apps = {
        "notepad": "notepad.exe",
        "calculator": "calc.exe",
        "paint": "mspaint.exe",
        "word": r"C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE",
        "excel": r"C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE",
        "powerpoint": r"C:\Program Files\Microsoft Office\root\Office16\POWERPNT.EXE",
        "command prompt": "cmd.exe",
        "cmd": "cmd.exe"
    }

    if app_name in apps:
        try:
            subprocess.Popen(apps[app_name])
            speak(f"Opening {app_name}")
            time.sleep(2)

            # Example: Automatically type something in Notepad
            if app_name == "notepad":
                pyautogui.write("Hello! I'm JARVIS. 😄", interval=0.1)
        except Exception as e:
            speak("Sorry, I couldn't open the application.")
    else:
        speak("Application not found in my list.")

def automate_option_inside_app(app_name):
    if app_name == "notepad":
        pyautogui.hotkey("ctrl", "s")
        time.sleep(1)
        pyautogui.write("my_note.txt")
        pyautogui.press("enter")
        speak("Saved the file.")

def open_website(website):
    # Open a URL in the default web browser
    webbrowser.open(f"https://{website}")
    speak(f"Opening {website}")

# Function to open an app (like YouTube or Instagram)
def open_app(app_name):
    if app_name.lower() == "youtube":
        pywhatkit.playonyt("test")  # Open YouTube app
        speak("Opening YouTube")
    elif app_name.lower() == "instagram":
        webbrowser.open("https://www.instagram.com")  # Open Instagram in browser
        speak("Opening Instagram")
    elif app_name.lower() == "whatsapp":
        pywhatkit.open_web()  # Opens WhatsApp web
        speak("Opening WhatsApp")
    else:
        speak("Sorry, I can't open that app right now.")
        
def get_weather(city):
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={WEATHER_API_KEY}&units=metric"
    res = requests.get(url).json()
    if res.get("main"):
        temp = res['main']['temp']
        desc = res['weather'][0]['description']
        speak(f"{city} has {desc} with {temp}°C")

def get_news():
    speak("Fetching the latest news from Google...")
    news_feed = feedparser.parse("https://news.google.com/news/rss?hl=en-IN&gl=IN&ceid=IN:en")

    if news_feed.entries:
        for entry in news_feed.entries[:3]:
            speak(entry.title)
    else:
        speak("Sorry, I couldn't fetch the news right now.")


        
def send_whatsapp(number, message):
    pywhatkit.sendwhatmsg_instantly(number, message)
    speak("WhatsApp message sent.")

def send_email(to, subject, body):
    with smtplib.SMTP("smtp.gmail.com", 587) as smtp:
        smtp.starttls()
        smtp.login(EMAIL, PASSWORD)
        smtp.sendmail(EMAIL, to, f"Subject: {subject}\n\n{body}")
    speak("Email sent.")

def save_note(content):
    with open("notes.txt", "a") as file:
        file.write(content + "\n")
    speak("Note saved.")

def tell_joke():
    joke = pyjokes.get_joke()
    speak(joke)

def shutdown_computer():
    speak("Shutting down the computer. Goodbye!")
    os.system("shutdown /s /t 5")  # Shuts down after 5 seconds
    

