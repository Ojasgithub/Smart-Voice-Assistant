# media_control.py
import os
import pywhatkit
from assistant_core import speak

def open_app(app_name):
    apps = {
        "notepad": "notepad",
        "chrome": "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"
    }
    if app_name in apps:
        os.startfile(apps[app_name])
        speak(f"Opening {app_name}")
    else:
        speak(f"App {app_name} not found")

def play_youtube_video(query):
    pywhatkit.playonyt(query)
    speak(f"Playing {query} on YouTube")
