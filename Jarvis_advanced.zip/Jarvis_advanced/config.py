# config.py
OPENAI_API_KEY = "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"
WEATHER_API_KEY = "db18c93804b12ae715c0e16dc0e1d9c9"
NEWS_API_KEY = "fb143ea24b374efd999a6991f148baf4"

EMAIL = "dhananjay.shende2019@gmail.com"
PASSWORD = "faqb ngha rzgh bvrw"
